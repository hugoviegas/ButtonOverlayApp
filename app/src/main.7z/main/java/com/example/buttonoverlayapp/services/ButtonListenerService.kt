package com.example.buttonoverlayapp.services

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class ButtonListenerService : AccessibilityService() {

    override fun onKeyEvent(event: KeyEvent): Boolean {
        return when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                showOverlay("volume_up")
                true // Indica que o evento foi consumido
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                showOverlay("volume_down")
                true
            }
            KeyEvent.KEYCODE_POWER -> {
                showOverlay("power")
                true
            }
            else -> super.onKeyEvent(event)
        }
    }

    private fun showOverlay(buttonType: String) {
        OverlayService.showOverlay(this, buttonType)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Implementação obrigatória mas não utilizada
    }

    override fun onInterrupt() {
        // Implementação obrigatória
    }
}
