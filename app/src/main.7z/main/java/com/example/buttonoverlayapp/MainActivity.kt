package com.example.buttonoverlayapp

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.buttonoverlayapp.databinding.ActivityMainBinding
import com.example.buttonoverlayapp.services.ButtonListenerService
import com.example.buttonoverlayapp.services.OverlayService
import com.example.buttonoverlayapp.ui.theme.activities.SettingsActivity // Corrigido o import

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupButtons()
        startButtonService()
        checkOverlayPermission()
    }

    private fun setupButtons() {
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
        }

        binding.btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun startButtonService() {
        val serviceIntent = Intent(this, ButtonListenerService::class.java)
        startService(serviceIntent)
    }

    private fun checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(this)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        OverlayService.hideAllOverlays(getSystemService(WINDOW_SERVICE) as WindowManager)
    }
}
