package com.example.buttonoverlayapp.services

import android.content.Context
import android.view.Gravity
import android.view.WindowManager
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.example.buttonoverlayapp.utils.OverlayView

object OverlayService {
    private var overlayView: OverlayView? = null

    fun showOverlay(context: Context, buttonType: String) {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            gravity = Gravity.START or Gravity.TOP
        }

        try {
            overlayView = OverlayView(context).apply {
                setButtonType(buttonType)
                setPosition(loadPositionFromPrefs(context, buttonType))
            }

            windowManager.addView(overlayView, params)
            overlayView?.postDelayed({ hideOverlay(windowManager) }, 500)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideOverlay(windowManager: WindowManager) {
        overlayView?.let {
            windowManager.removeView(it)
            overlayView = null
        }
    }

    private fun loadPositionFromPrefs(context: Context, buttonType: String): Pair<Int, Int> {
        val prefs = PreferenceManager.getDefaultSharedPreferences(context)
        return Pair(
            prefs.getInt("${buttonType}_x", 100), // Valor padrão X
            prefs.getInt("${buttonType}_y", 100)  // Valor padrão Y
        )
    }

    fun savePosition(context: Context, buttonType: String, x: Int, y: Int) {
        PreferenceManager.getDefaultSharedPreferences(context).edit {
            putInt("${buttonType}_x", x)
            putInt("${buttonType}_y", y)
        }
    }

    fun hideAllOverlays(windowManager: WindowManager) {
        hideOverlay(windowManager)
    }
}
