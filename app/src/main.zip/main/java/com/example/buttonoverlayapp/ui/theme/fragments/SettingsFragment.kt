package com.example.buttonoverlayapp.ui.theme.fragments

import android.os.Bundle
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.example.buttonoverlayapp.R

class SettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<Preference>("overlay_position")?.setOnPreferenceClickListener {
            // Navegar para tela de ajuste de posição
            true
        }
    }
}
